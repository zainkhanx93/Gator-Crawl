module.exports = {
    JWT_SECRET: 'TEAM1'
}